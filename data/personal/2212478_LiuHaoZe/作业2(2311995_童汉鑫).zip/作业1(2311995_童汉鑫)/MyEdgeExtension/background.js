chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: changeBackgroundColor
  });
});

function changeBackgroundColor() {
  // 方法：创建一个全屏的绿色透明层，覆盖在所有内容上面
  const overlay = document.createElement('div');
  
  // 设置样式：固定定位、全屏、半透明绿色、层级最高
  // pointer-events: none 保证鼠标可以透过这个层点击下面的视频，不影响操作
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: rgba(0, 255, 0, 0.2); 
    z-index: 2147483647;
    pointer-events: none;
  `;
  
  // 把它加到页面里
  document.body.appendChild(overlay);
  
  alert('插件已工作：护眼滤镜已开启！');
}