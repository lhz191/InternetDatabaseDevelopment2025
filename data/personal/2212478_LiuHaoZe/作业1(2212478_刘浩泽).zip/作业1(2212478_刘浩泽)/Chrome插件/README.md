# 📝 网页笔记助手 Chrome插件

一个强大的网页标注和笔记工具，支持文本高亮、添加笔记、快速标记等功能。

## ✨ 功能特点

### 1. 多色高亮标注
- 🟡 黄色高亮
- 🟢 绿色高亮
- 🔵 蓝色高亮
- 🔴 粉色高亮

### 2. 智能笔记管理
- 📌 为高亮文本添加笔记
- 💾 自动保存到本地存储
- 🔍 快速查看和管理笔记

### 3. 便捷操作方式
- 🖱️ 鼠标右键菜单
- ⌨️ 键盘快捷键
- 🎯 插件弹窗界面

### 4. 数据导出
- 📊 统计高亮和笔记数量
- 💾 导出为文本文件
- 📱 跨页面数据保存

## 🚀 安装步骤

### 方法一：开发者模式安装（推荐）

1. **生成图标文件**
   - 打开 `图标生成器.html`
   - 点击"下载全部"按钮
   - 将下载的3个图标文件（icon16.png、icon48.png、icon128.png）保存到 `icons` 文件夹中

2. **打开Chrome扩展程序页面**
   - 在Chrome浏览器地址栏输入：`chrome://extensions/`
   - 或者：点击右上角三个点 → 更多工具 → 扩展程序

3. **启用开发者模式**
   - 在页面右上角找到"开发者模式"开关
   - 将其打开（变为蓝色）

4. **加载插件**
   - 点击左上角"加载已解压的扩展程序"按钮
   - 选择整个 `任务3-Chrome插件` 文件夹
   - 点击"选择文件夹"

5. **验证安装**
   - 插件列表中出现"网页笔记助手"
   - 浏览器工具栏出现插件图标
   - 可以点击图标打开弹窗

### 方法二：打包安装

1. 完成上述步骤1（生成图标）
2. 在 `chrome://extensions/` 页面点击"打包扩展程序"
3. 选择插件文件夹，生成 .crx 文件
4. 将 .crx 文件拖入Chrome安装

## 📖 使用方法

### 方式1：使用插件弹窗

1. 在网页上选中要高亮的文本
2. 点击浏览器工具栏的插件图标
3. 在弹窗中选择高亮颜色
4. 或点击"添加笔记"按钮输入笔记内容

### 方式2：使用右键菜单

1. 在网页上选中文本
2. 右键点击选中的文本
3. 在菜单中选择高亮颜色或添加笔记

### 方式3：使用快捷键

| 功能 | Windows/Linux | Mac |
|------|--------------|-----|
| 黄色高亮 | `Ctrl + Shift + Y` | `Cmd + Shift + Y` |
| 绿色高亮 | `Ctrl + Shift + G` | `Cmd + Shift + G` |
| 添加笔记 | `Ctrl + Shift + N` | `Cmd + Shift + N` |

### 管理笔记

- **查看笔记**：将鼠标悬停在高亮文本上，显示笔记内容
- **删除高亮**：右键点击高亮文本，选择"删除"
- **清除所有**：打开插件弹窗，点击"清除所有高亮"
- **导出笔记**：打开插件弹窗，点击"导出笔记"

## 📂 文件结构

```
任务3-Chrome插件/
├── manifest.json          # 插件配置文件
├── popup.html            # 弹窗页面
├── popup.js              # 弹窗脚本
├── content.js            # 内容脚本（注入到网页）
├── content.css           # 内容样式
├── background.js         # 后台脚本
├── icons/                # 图标文件夹
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── 图标生成器.html        # 图标生成工具
└── README.md             # 说明文档
```

## 🔧 技术实现

### Manifest V3
使用最新的Chrome Extension Manifest V3规范，确保兼容性和安全性。

### 核心技术
- **Storage API**: 本地数据存储
- **Content Scripts**: 网页内容注入
- **Background Service Worker**: 后台任务处理
- **Context Menus**: 右键菜单集成
- **Commands API**: 快捷键支持

### 关键功能实现

#### 1. 文本高亮
```javascript
function highlightSelection(color) {
    const selection = window.getSelection();
    const range = selection.getRangeAt(0);
    const span = document.createElement('span');
    span.className = `web-note-highlight web-note-${color}`;
    range.surroundContents(span);
}
```

#### 2. 数据持久化
```javascript
async function saveData() {
    const url = window.location.href;
    await chrome.storage.local.set({ [url]: pageData });
}
```

#### 3. 消息通信
```javascript
// popup.js -> content.js
chrome.tabs.sendMessage(tabId, { action: 'highlight', color: 'yellow' });

// content.js监听
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'highlight') {
        highlightSelection(request.color);
        sendResponse({ success: true });
    }
});
```

## 🎨 界面设计

### 弹窗界面特点
- 现代化渐变色设计
- 响应式布局
- 清晰的功能分区
- 实时统计信息显示

### 网页标注样式
- 半透明背景色
- 底部彩色边框
- 悬停提示效果
- 笔记标记图标

## 📊 数据存储

### 存储结构
```javascript
{
  "https://example.com": {
    "highlights": [
      {
        "id": "1234567890",
        "text": "被高亮的文本",
        "color": "yellow",
        "timestamp": "2025-11-22T..."
      }
    ],
    "notes": [
      {
        "id": "1234567890",
        "highlightText": "被标注的文本",
        "noteContent": "我的笔记内容",
        "timestamp": "2025-11-22T..."
      }
    ]
  }
}
```

## ⚠️ 注意事项

1. **数据保存**：笔记和高亮数据保存在本地，卸载插件后会丢失
2. **页面刷新**：当前版本刷新页面后高亮会消失（需手动恢复功能）
3. **兼容性**：部分特殊网页可能无法正常使用高亮功能
4. **权限说明**：
   - `storage`: 保存笔记数据
   - `activeTab`: 操作当前标签页
   - `contextMenus`: 添加右键菜单

## 🔄 功能扩展建议

可以在此基础上继续开发：
- 云端同步功能
- 笔记搜索功能
- 导出为PDF格式
- 团队协作功能
- 语音笔记功能
- OCR图片识别

## 🐛 常见问题

### Q1: 安装后图标不显示？
**A**: 确保已经生成并放置了图标文件到 icons 文件夹中。

### Q2: 快捷键不生效？
**A**: 
- 检查快捷键是否与其他插件冲突
- 在 `chrome://extensions/shortcuts` 中查看和修改快捷键

### Q3: 刷新页面后高亮消失？
**A**: 当前版本的简化实现，高亮恢复功能需要更复杂的文本定位算法。

### Q4: 某些网页无法使用？
**A**: 
- Chrome应用商店等特殊页面限制插件运行
- 需要刷新页面后才能使用
- 检查控制台是否有错误信息

## 📝 作业说明

### 插件功能说明
本插件实现了以下核心功能：
1. 多色文本高亮标注
2. 为高亮添加笔记
3. 数据本地存储
4. 笔记导出功能
5. 右键菜单集成
6. 快捷键支持
7. 统计信息显示

### 使用的技术
- Chrome Extension Manifest V3
- JavaScript ES6+
- Chrome Storage API
- Chrome Runtime API
- Chrome Context Menus API
- Chrome Commands API
- HTML5 + CSS3

### 演示步骤
1. 安装插件
2. 打开任意网页
3. 选中文本并高亮
4. 添加笔记
5. 导出笔记
6. 展示统计信息

## 📚 参考资料

- [Chrome Extension 官方文档](https://developer.chrome.com/docs/extensions/)
- [Manifest V3 迁移指南](https://developer.chrome.com/docs/extensions/mv3/intro/)
- [Storage API 文档](https://developer.chrome.com/docs/extensions/reference/storage/)

## 👨‍💻 开发者

作业项目 - 互联网数据库课程
南开大学 计算机学院

---

**版本**: 1.0.0
**最后更新**: 2025-11-22

