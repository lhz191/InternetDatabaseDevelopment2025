// 显示提示消息
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2000);
}

// 获取当前标签页
async function getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
}

// 向内容脚本发送消息
async function sendMessageToContent(message) {
    const tab = await getCurrentTab();
    try {
        const response = await chrome.tabs.sendMessage(tab.id, message);
        return response;
    } catch (error) {
        console.error('发送消息失败:', error);
        showToast('❌ 操作失败，请刷新页面后重试');
        return null;
    }
}

// 更新统计信息
async function updateStats() {
    const response = await sendMessageToContent({ action: 'getStats' });
    if (response) {
        document.getElementById('highlightCount').textContent = response.highlightCount || 0;
        document.getElementById('noteCount').textContent = response.noteCount || 0;
    }
}

// 高亮颜色按钮点击事件
document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const color = btn.dataset.color;
        const response = await sendMessageToContent({
            action: 'highlight',
            color: color
        });
        
        if (response && response.success) {
            showToast(`✅ 已添加${btn.textContent.trim()}高亮`);
            updateStats();
        }
    });
});

// 添加笔记按钮
document.getElementById('addNoteBtn').addEventListener('click', async () => {
    const response = await sendMessageToContent({ action: 'addNote' });
    
    if (response && response.success) {
        showToast('✅ 笔记已添加');
        updateStats();
    }
});

// 清除所有高亮
document.getElementById('clearBtn').addEventListener('click', async () => {
    if (confirm('确定要清除当前页面的所有高亮和笔记吗？')) {
        const response = await sendMessageToContent({ action: 'clearAll' });
        
        if (response && response.success) {
            showToast('✅ 已清除所有标注');
            updateStats();
        }
    }
});

// 导出笔记
document.getElementById('exportBtn').addEventListener('click', async () => {
    const response = await sendMessageToContent({ action: 'exportNotes' });
    
    if (response && response.success) {
        // 创建下载链接
        const blob = new Blob([response.data], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `网页笔记_${new Date().toLocaleDateString()}.txt`;
        a.click();
        URL.revokeObjectURL(url);
        
        showToast('✅ 笔记已导出');
    } else {
        showToast('❌ 暂无笔记可导出');
    }
});

// 页面加载时更新统计
document.addEventListener('DOMContentLoaded', () => {
    updateStats();
});

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateStats') {
        updateStats();
    }
});


