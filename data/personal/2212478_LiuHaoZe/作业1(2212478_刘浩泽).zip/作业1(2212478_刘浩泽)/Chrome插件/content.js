// 网页笔记助手 - 内容脚本
console.log('🎨 网页笔记助手已加载');

// 存储当前页面的高亮和笔记数据
let pageData = {
    highlights: [],
    notes: []
};

// 从本地存储加载数据
async function loadData() {
    const url = window.location.href;
    const result = await chrome.storage.local.get(url);
    if (result[url]) {
        pageData = result[url];
        restoreHighlights();
    }
}

// 保存数据到本地存储
async function saveData() {
    const url = window.location.href;
    await chrome.storage.local.set({ [url]: pageData });
}

// 高亮选中的文本
function highlightSelection(color) {
    const selection = window.getSelection();
    
    if (!selection || selection.toString().trim() === '') {
        showNotification('⚠️ 请先选中要高亮的文本');
        return false;
    }
    
    const selectedText = selection.toString();
    const range = selection.getRangeAt(0);
    
    // 创建高亮元素
    const span = document.createElement('span');
    span.className = `web-note-highlight web-note-${color}`;
    span.setAttribute('data-note-id', Date.now().toString());
    span.setAttribute('title', '点击添加笔记或右键删除');
    
    try {
        // 使用更可靠的方法来包裹选中内容
        const documentFragment = range.extractContents();
        span.appendChild(documentFragment);
        range.insertNode(span);
        
        // 保存高亮信息
        pageData.highlights.push({
            id: span.getAttribute('data-note-id'),
            text: selectedText,
            color: color,
            timestamp: new Date().toISOString()
        });
        
        saveData();
        
        // 添加点击事件
        span.addEventListener('click', (e) => {
            e.stopPropagation();
            addNoteToHighlight(span);
        });
        
        // 添加右键菜单
        span.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            if (confirm('是否删除这个高亮？')) {
                removeHighlight(span);
            }
        });
        
        // 清除选择
        selection.removeAllRanges();
        
        // 显示成功通知
        showNotification(`✅ 已添加${getColorName(color)}高亮`);
        
        return true;
    } catch (error) {
        console.error('高亮失败:', error);
        showNotification('❌ 无法高亮此区域，请尝试选择其他文本');
        return false;
    }
}

// 获取颜色名称
function getColorName(color) {
    const colorNames = {
        'yellow': '黄色',
        'green': '绿色',
        'blue': '蓝色',
        'pink': '粉色'
    };
    return colorNames[color] || color;
}

// 恢复保存的高亮
function restoreHighlights() {
    // 注意：这是一个简化实现
    // 实际应用中需要更复杂的文本定位算法
    console.log('恢复高亮数据:', pageData.highlights.length + ' 个');
}

// 为高亮添加笔记
function addNoteToHighlight(element) {
    const noteId = element.getAttribute('data-note-id');
    const text = element.textContent;
    const note = prompt(`为选中的文本添加笔记：\n"${text.substring(0, 50)}..."`);
    
    if (note && note.trim() !== '') {
        pageData.notes.push({
            id: noteId,
            highlightText: text,
            noteContent: note,
            timestamp: new Date().toISOString()
        });
        
        saveData();
        
        // 添加标记显示有笔记
        element.classList.add('has-note');
        element.setAttribute('data-note', note);
        
        // 更新title
        element.setAttribute('title', `笔记: ${note}`);
        
        showNotification('✅ 笔记已保存');
    }
}

// 添加笔记（不依赖高亮）
function addNote() {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();
    
    if (selectedText === '') {
        alert('请先选中文本');
        return false;
    }
    
    const note = prompt(`为选中的文本添加笔记：\n"${selectedText.substring(0, 50)}..."`);
    
    if (note && note.trim() !== '') {
        // 先高亮，再添加笔记
        if (highlightSelection('yellow')) {
            const highlights = document.querySelectorAll('.web-note-highlight');
            const lastHighlight = highlights[highlights.length - 1];
            
            if (lastHighlight) {
                const noteId = lastHighlight.getAttribute('data-note-id');
                pageData.notes.push({
                    id: noteId,
                    highlightText: selectedText,
                    noteContent: note,
                    timestamp: new Date().toISOString()
                });
                
                lastHighlight.classList.add('has-note');
                lastHighlight.setAttribute('data-note', note);
                lastHighlight.setAttribute('title', `笔记: ${note}`);
                
                saveData();
            }
        }
        return true;
    }
    
    return false;
}

// 移除高亮
function removeHighlight(element) {
    const noteId = element.getAttribute('data-note-id');
    
    // 从数据中移除
    pageData.highlights = pageData.highlights.filter(h => h.id !== noteId);
    pageData.notes = pageData.notes.filter(n => n.id !== noteId);
    
    // 从DOM中移除（保留文本）
    const parent = element.parentNode;
    while (element.firstChild) {
        parent.insertBefore(element.firstChild, element);
    }
    parent.removeChild(element);
    
    saveData();
    showNotification('✅ 高亮已删除');
}

// 清除所有高亮
function clearAll() {
    const highlights = document.querySelectorAll('.web-note-highlight');
    highlights.forEach(element => {
        const parent = element.parentNode;
        while (element.firstChild) {
            parent.insertBefore(element.firstChild, element);
        }
        parent.removeChild(element);
    });
    
    pageData.highlights = [];
    pageData.notes = [];
    saveData();
    
    return true;
}

// 导出笔记
function exportNotes() {
    if (pageData.notes.length === 0 && pageData.highlights.length === 0) {
        return { success: false };
    }
    
    let content = `网页笔记导出\n`;
    content += `URL: ${window.location.href}\n`;
    content += `导出时间: ${new Date().toLocaleString()}\n`;
    content += `\n${'='.repeat(50)}\n\n`;
    
    if (pageData.highlights.length > 0) {
        content += `## 高亮文本 (${pageData.highlights.length}个)\n\n`;
        pageData.highlights.forEach((highlight, index) => {
            content += `${index + 1}. [${highlight.color}] ${highlight.text}\n`;
            content += `   时间: ${new Date(highlight.timestamp).toLocaleString()}\n\n`;
        });
    }
    
    if (pageData.notes.length > 0) {
        content += `\n## 笔记 (${pageData.notes.length}个)\n\n`;
        pageData.notes.forEach((note, index) => {
            content += `${index + 1}. 原文: ${note.highlightText}\n`;
            content += `   笔记: ${note.noteContent}\n`;
            content += `   时间: ${new Date(note.timestamp).toLocaleString()}\n\n`;
        });
    }
    
    return {
        success: true,
        data: content
    };
}

// 获取统计信息
function getStats() {
    return {
        highlightCount: pageData.highlights.length,
        noteCount: pageData.notes.length
    };
}

// 显示通知
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'web-note-notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 2000);
}

// 监听来自popup和background的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('收到消息:', request);
    
    // 处理action类型的消息
    if (request.action) {
        switch (request.action) {
            case 'highlight':
                const success = highlightSelection(request.color);
                sendResponse({ success: success });
                break;
                
            case 'addNote':
                const noteAdded = addNote();
                sendResponse({ success: noteAdded });
                break;
                
            case 'clearAll':
                const cleared = clearAll();
                sendResponse({ success: cleared });
                break;
                
            case 'exportNotes':
                const exportResult = exportNotes();
                sendResponse(exportResult);
                break;
                
            case 'getStats':
                const stats = getStats();
                sendResponse(stats);
                break;
                
            default:
                sendResponse({ success: false, error: 'Unknown action' });
        }
    }
    
    // 处理command类型的消息（快捷键）
    if (request.command) {
        switch (request.command) {
            case 'highlight-yellow':
                const successYellow = highlightSelection('yellow');
                sendResponse({ success: successYellow });
                break;
            case 'highlight-green':
                const successGreen = highlightSelection('green');
                sendResponse({ success: successGreen });
                break;
            case 'add-note':
                const noteAdded = addNote();
                sendResponse({ success: noteAdded });
                break;
            default:
                sendResponse({ success: false });
        }
    }
    
    return true; // 保持消息通道开启
});

// 页面加载时恢复数据
loadData();

