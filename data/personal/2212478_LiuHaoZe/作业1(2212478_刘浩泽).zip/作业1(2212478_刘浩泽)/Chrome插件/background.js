// 网页笔记助手 - 后台脚本

console.log('网页笔记助手后台服务已启动');

// 监听快捷键命令
chrome.commands.onCommand.addListener((command) => {
    console.log('快捷键触发:', command);
    
    // 获取当前活动标签页
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
            // 发送命令到content script
            chrome.tabs.sendMessage(tabs[0].id, { command: command }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error('发送命令失败:', chrome.runtime.lastError);
                }
            });
        }
    });
});

// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
    console.log('插件已安装/更新');
    
    // 创建上下文菜单
    chrome.contextMenus.create({
        id: 'highlight-yellow',
        title: '🟡 黄色高亮',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'highlight-green',
        title: '🟢 绿色高亮',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'highlight-blue',
        title: '🔵 蓝色高亮',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'highlight-pink',
        title: '🔴 粉色高亮',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'separator',
        type: 'separator',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'add-note',
        title: '📝 添加笔记',
        contexts: ['selection']
    });
});

// 监听右键菜单点击
chrome.contextMenus.onClicked.addListener((info, tab) => {
    console.log('右键菜单点击:', info.menuItemId);
    
    let action = '';
    let color = '';
    
    switch (info.menuItemId) {
        case 'highlight-yellow':
            action = 'highlight';
            color = 'yellow';
            break;
        case 'highlight-green':
            action = 'highlight';
            color = 'green';
            break;
        case 'highlight-blue':
            action = 'highlight';
            color = 'blue';
            break;
        case 'highlight-pink':
            action = 'highlight';
            color = 'pink';
            break;
        case 'add-note':
            action = 'addNote';
            break;
    }
    
    if (action) {
        chrome.tabs.sendMessage(tab.id, { 
            action: action, 
            color: color 
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('发送消息失败:', chrome.runtime.lastError);
            }
        });
    }
});

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'notification') {
        // 可以在这里添加系统通知
        console.log('通知:', request.message);
    }
    
    sendResponse({ received: true });
    return true;
});


