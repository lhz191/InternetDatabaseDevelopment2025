document.addEventListener('DOMContentLoaded', function() {
    // 获取当前激活的标签页
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs && tabs.length > 0) {
            var activeTab = tabs[0];
            var url = activeTab.url;
            
            // 更新UI显示URL
            var urlText = document.getElementById('url-text');
            urlText.textContent = url;
            
            // 使用 QR Server API 生成二维码图片
            // 将URL进行编码以作为参数传递
            var qrImage = document.getElementById('qrcode-img');
            var apiUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(url);
            
            qrImage.src = apiUrl;
            
            // 简单的加载状态处理
            qrImage.onload = function() {
                // 图片加载完成
            };
            
            qrImage.onerror = function() {
                qrImage.alt = "无法加载二维码，请检查网络连接";
                qrImage.style.display = 'none';
                document.getElementById('qrcode-container').innerText = "加载失败";
            };
        }
    });
});
